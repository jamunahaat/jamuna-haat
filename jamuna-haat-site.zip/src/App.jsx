import React, { useState, useEffect } from "react";
import { ShoppingCart, Baby, Leaf, Utensils, LogIn, PlusCircle, Trash2, Image as ImageIcon, Video } from "lucide-react";

const getLocalData = (key, defaultVal) => {
  try {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : defaultVal;
  } catch {
    return defaultVal;
  }
};

const Button = ({ children, ...props }) => (
  <button className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 disabled:bg-gray-300 disabled:cursor-not-allowed" {...props}>{children}</button>
);

const Input = (props) => (
  <input className="border px-2 py-1 w-full rounded text-black" {...props} />
);

const Label = ({ children }) => (
  <label className="block text-sm font-medium text-black mb-1">{children}</label>
);

const Card = ({ children, ...props }) => (
  <div className="border rounded shadow-sm bg-white" {...props}>{children}</div>
);

const CardContent = ({ children, ...props }) => (
  <div className="p-4" {...props}>{children}</div>
);

const iconMap = {
  baby: <Baby />,
  leaf: <Leaf />,
  utensils: <Utensils />, 
  default: <PlusCircle />,
};

export default function HomePage() {
  const [products, setProducts] = useState(() => getLocalData("products", [
    { id: 1, name: "Baby Lotion", category: "Baby Products", icon: "baby", price: "৮০", stock: 10, sold: 0, image: "/images/babylotion.jpg" },
    { id: 2, name: "জৈব সার", category: "Agriculture Products", icon: "leaf", price: "১২০", stock: 5, sold: 0, image: "/images/fertilizer.jpg" },
    { id: 3, name: "তেল", category: "Cooking Products", icon: "utensils", price: "৫০", stock: 0, sold: 0, image: "/images/cookingoil.jpg" },
  ]));

  const [cart, setCart] = useState(() => getLocalData("cart", []));
  const [adminMode, setAdminMode] = useState(false);
  const [deliveryMode, setDeliveryMode] = useState(false);
  const [newProduct, setNewProduct] = useState({ name: "", category: "", price: "", stock: 0, icon: "default", image: "", video: "" });
  const [isLoggedIn, setIsLoggedIn] = useState(() => getLocalData("isLoggedIn", false));
  const [contactInfo, setContactInfo] = useState(() => getLocalData("contactInfo", {
    address: "Alampur, Kazipur, Sirajganj",
    phone1: "01841201828",
    phone2: "01780117519",
    email: "jamunamart@gmail.com",
  }));

  const [deliveryDetails, setDeliveryDetails] = useState({ address: "", phone: "" });
  const [searchTerm, setSearchTerm] = useState("");
  const [stockFilter, setStockFilter] = useState("all");
  const [notifications, setNotifications] = useState([]);
  const [checkoutComplete, setCheckoutComplete] = useState(false);
  const [orders, setOrders] = useState(() => getLocalData("orders", []));
  const [customer, setCustomer] = useState(() => getLocalData("customer", { email: "", password: "", isLoggedIn: false }));
  const [customerInput, setCustomerInput] = useState({ email: "", password: "" });
  const [deliveryStatus, setDeliveryStatus] = useState(() => getLocalData("deliveryStatus", {}));
  const [userRole, setUserRole] = useState("customer");

  useEffect(() => { localStorage.setItem("products", JSON.stringify(products)); }, [products]);
  useEffect(() => { try { localStorage.setItem("cart", JSON.stringify(cart)); } catch (e) { console.warn("Cart could not be saved."); } }, [cart]);
  useEffect(() => { localStorage.setItem("isLoggedIn", JSON.stringify(isLoggedIn)); }, [isLoggedIn]);
  useEffect(() => { localStorage.setItem("contactInfo", JSON.stringify(contactInfo)); }, [contactInfo]);
  useEffect(() => { localStorage.setItem("customer", JSON.stringify(customer)); }, [customer]);
  useEffect(() => { localStorage.setItem("orders", JSON.stringify(orders)); }, [orders]);
  useEffect(() => { localStorage.setItem("deliveryStatus", JSON.stringify(deliveryStatus)); }, [deliveryStatus]);

  const handleCustomerLogin = () => {
    if (customerInput.email && customerInput.password) {
      if (userRole === "admin" && customerInput.email === "jamunahaat@gmail.com" && customerInput.password === "jamuna1234") {
        setIsLoggedIn(true);
        setAdminMode(true);
      } else if (userRole === "delivery" && customerInput.email === "deliveryman@jamuna.com" && customerInput.password === "delivery123") {
        setIsLoggedIn(true);
        setDeliveryMode(true);
      } else if (userRole === "customer") {
        setCustomer({ email: customerInput.email, password: customerInput.password, isLoggedIn: true });
      }
    }
  };

  const handleCustomerLogout = () => {
    setCustomer({ email: "", password: "", isLoggedIn: false });
    setIsLoggedIn(false);
    setAdminMode(false);
    setDeliveryMode(false);
  };

  const handleAddToCart = (product) => {
    if (product.stock > 0) {
      const existing = cart.find(item => item.id === product.id);
      if (existing) {
        setCart(cart.map(item => item.id === product.id ? { ...item, qty: item.qty + 1 } : item));
      } else {
        setCart([...cart, { ...product, qty: 1 }]);
      }
    }
  };

  const handleCheckout = () => {
    const orderId = Date.now();
    setOrders([...orders, { id: orderId, cart, customer, deliveryDetails }]);
    setDeliveryStatus({ ...deliveryStatus, [orderId]: "Pending" });
    setCheckoutComplete(true);
    setCart([]);
  };

  const handleDeleteOrder = (id) => {
    setOrders(orders.filter(order => order.id !== id));
    const updatedStatus = { ...deliveryStatus };
    delete updatedStatus[id];
    setDeliveryStatus(updatedStatus);
  };

  const handleStatusUpdate = (id, status) => {
    setDeliveryStatus({ ...deliveryStatus, [id]: status });
  };

  const totalItems = cart.reduce((sum, item) => sum + item.qty, 0);

  return (
    <main className="min-h-screen bg-white text-black">
      <header className="p-4 bg-green-700 text-white flex items-center justify-between">
        <div className="flex items-center gap-4">
          <img src="/logo.png" alt="Jamuna Haat Logo" className="h-12 w-auto" />
          <h1 className="text-2xl font-bold">Jamuna Haat</h1>
        </div>
        <div className="flex gap-2 items-center">
          <div className="relative">
            <ShoppingCart className="w-6 h-6" />
            {totalItems > 0 && (
              <span className="absolute -top-2 -right-2 bg-red-600 text-white rounded-full px-2 text-xs">{totalItems}</span>
            )}
          </div>
          {customer.isLoggedIn || isLoggedIn ? (
            <Button onClick={handleCustomerLogout}>Logout</Button>
          ) : (
            <div className="flex gap-2">
              <select value={userRole} onChange={e => setUserRole(e.target.value)} className="border px-2 py-1 rounded">
                <option value="customer">Customer</option>
                <option value="delivery">Delivery Man</option>
                <option value="admin">Admin</option>
              </select>
              <Input type="email" placeholder="Email" value={customerInput.email} onChange={e => setCustomerInput({ ...customerInput, email: e.target.value })} />
              <Input type="password" placeholder="Password" value={customerInput.password} onChange={e => setCustomerInput({ ...customerInput, password: e.target.value })} />
              <Button onClick={handleCustomerLogin}>Login</Button>
            </div>
          )}
        </div>
      </header>

      {/* ⬇️ Full UI preview rendering to be added below */}
      <div className="p-4">
        <h2 className="text-xl font-semibold mb-4">প্রোডাক্ট তালিকা</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {products.map((product) => (
            <Card key={product.id}>
              <CardContent>
                <img src={product.image} alt={product.name} className="w-full h-32 object-cover rounded mb-2" />
                <h3 className="text-lg font-bold">{product.name}</h3>
                <p>মূল্য: {product.price} BDT</p>
                <p>স্টকে আছে: {product.stock} | বিক্রি: {product.sold}</p>
                <Button onClick={() => handleAddToCart(product)} disabled={product.stock === 0}>কার্টে যোগ করুন</Button>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="mt-8">
          <h2 className="text-xl font-semibold mb-2">চেকআউট</h2>
          <Input placeholder="ডেলিভারি ঠিকানা" value={deliveryDetails.address} onChange={e => setDeliveryDetails({ ...deliveryDetails, address: e.target.value })} />
          <Input placeholder="মোবাইল নম্বর" value={deliveryDetails.phone} onChange={e => setDeliveryDetails({ ...deliveryDetails, phone: e.target.value })} />
          <Button className="mt-2" onClick={handleCheckout}>চেকআউট করুন</Button>
        </div>
      </div>

      <footer className="bg-green-800 text-white p-4 text-center mt-6">
        <p>Jamuna Haat &copy; 2025 | Contact: {contactInfo.phone1}, {contactInfo.email}</p>
      </footer>
    </main>
  );
}
