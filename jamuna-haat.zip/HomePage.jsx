
import React, { useState, useEffect } from "react";
import { ShoppingCart, Baby, Leaf, Utensils, LogIn, PlusCircle, Trash2, Image as ImageIcon, Video } from "lucide-react";

// ... (trimmed for brevity) ...
